import { renderComments } from './modules/renderComments.js';
import { initAddCommentListener } from './modules/initListeners.js';
import { updateComments } from './modules/comments.js';

fetch('https://wedev-api.sky.pro/api/v1/vladyslav-kozloff/comments')
    .then((response) => {
        return response.json();
    })
    .then((data) => {
        /* console.log(data.comments[0].author.name);
        console.log(data.comments[0].text);
        console.log(data.comments[0].date); */
        updateComments(data.comments);
    });

renderComments();
initAddCommentListener(renderComments);
